#!/usr/bin/python3
# -*- coding: utf-8 -*-

# Copyright (C) 2019, Alexander Kostuchkov

"""
This file is part of CheckEmail.

    CheckEmail is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    CheckEmail is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CheckEmail.  If not, see <https://www.gnu.org/licenses/>.

  (Этот файл — часть CheckEmail.

   CheckEmail - свободная программа: вы можете перераспространять ее и/или
   изменять ее на условиях Стандартной общественной лицензии GNU в том виде,
   в каком она была опубликована Фондом свободного программного обеспечения;
   либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
   версии.

   CheckEmail распространяется в надежде, что она будет полезной,
   но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
   или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Стандартной
   общественной лицензии GNU.

   Вы должны были получить копию Стандартной общественной лицензии GNU
   вместе с этой программой. Если это не так, см.
   <https://www.gnu.org/licenses/>.)
"""

from PyQt5 import QtCore


class CCheckEmailbox(QtCore.QObject):
    """ Thread is run by actCheckEmbxs_triggered and actCheckSelectedEmbxs_triggered in fMain.py """
    emlbxsChecked = QtCore.pyqtSignal(dict)
    finished = QtCore.pyqtSignal()

    def __init__(self, myCheckEmbx, selectedEmbxsList = [], parent=None):
        QtCore.QObject.__init__(self, parent)
        self._myCheckEmbx = myCheckEmbx
        self._selectedEmbxsList = selectedEmbxsList

    @QtCore.pyqtSlot()
    def checkEmailbox(self):
        """ Check Emailboxes """
        # pass empty list (if no param) => check all Emailboxes
        resultDict = self._myCheckEmbx.checkEmails(self._selectedEmbxsList)
        self.emlbxsChecked.emit(resultDict)
        # emit finished to kill this thread
        self.finished.emit()
