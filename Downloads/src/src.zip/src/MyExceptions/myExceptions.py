#!/usr/bin/python3
# -*- coding: utf-8 -*-

# Copyright (C) 2019, Alexander Kostuchkov

"""
This file is part of CheckEmail.

    CheckEmail is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    CheckEmail is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CheckEmail.  If not, see <https://www.gnu.org/licenses/>.

  (Этот файл — часть CheckEmail.

   CheckEmail - свободная программа: вы можете перераспространять ее и/или
   изменять ее на условиях Стандартной общественной лицензии GNU в том виде,
   в каком она была опубликована Фондом свободного программного обеспечения;
   либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
   версии.

   CheckEmail распространяется в надежде, что она будет полезной,
   но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
   или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Стандартной
   общественной лицензии GNU.

   Вы должны были получить копию Стандартной общественной лицензии GNU
   вместе с этой программой. Если это не так, см.
   <https://www.gnu.org/licenses/>.)
"""


class MyIMAP4ConnectionError(Exception):
    """ My Exception for imaplib.IMAP4_SSL(serverName, port) """
    def __init__(self, message="Cannot connect to IMAP4 server."):
        self.message = message

    def __str__(self):
        return self.message


class MyIMAP4LoginError(Exception):
    """ My Exception for imaplib.login(fullEmail, password) """
    def __init__(self, message="Cannot login."):
        self.message = message

    def __str__(self):
        return self.message


class MyEmailboxLoginError(Exception):
    """ My Exception for login Emailbox. """
    pass


class MyBadBrowserOrOSError(Exception):
    """ If Windows XP or unknown browser in using. """
    pass