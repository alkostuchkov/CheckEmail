<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>dlgPopupMsg</name>
    <message>
        <location filename="../Gui/dlgPopupMsgUI.ui" line="20"/>
        <source>Check Email</source>
        <translation>Проверка почты</translation>
    </message>
</context>
</TS>
