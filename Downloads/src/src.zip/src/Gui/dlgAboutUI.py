# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'dlgAboutUI.ui'
#
# Created by: PyQt5 UI code generator 5.8
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_dlgAbout(object):
    def setupUi(self, dlgAbout):
        dlgAbout.setObjectName("dlgAbout")
        dlgAbout.resize(650, 315)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(dlgAbout.sizePolicy().hasHeightForWidth())
        dlgAbout.setSizePolicy(sizePolicy)
        dlgAbout.setMinimumSize(QtCore.QSize(650, 315))
        dlgAbout.setMaximumSize(QtCore.QSize(650, 315))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(13)
        dlgAbout.setFont(font)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/icons/Icons/CheckEmail.ico"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        dlgAbout.setWindowIcon(icon)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(dlgAbout)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.lblProgIcon = QtWidgets.QLabel(dlgAbout)
        self.lblProgIcon.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.lblProgIcon.setText("")
        self.lblProgIcon.setPixmap(QtGui.QPixmap(":/icons/Icons/CheckEmail.ico"))
        self.lblProgIcon.setObjectName("lblProgIcon")
        self.verticalLayout_2.addWidget(self.lblProgIcon)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem)
        self.horizontalLayout_2.addLayout(self.verticalLayout_2)
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.twAbout = QtWidgets.QTabWidget(dlgAbout)
        self.twAbout.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.twAbout.setTabPosition(QtWidgets.QTabWidget.North)
        self.twAbout.setObjectName("twAbout")
        self.tabAboutProgram = QtWidgets.QWidget()
        self.tabAboutProgram.setObjectName("tabAboutProgram")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout(self.tabAboutProgram)
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.tbrAboutProgram = QtWidgets.QTextBrowser(self.tabAboutProgram)
        self.tbrAboutProgram.viewport().setProperty("cursor", QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.tbrAboutProgram.setObjectName("tbrAboutProgram")
        self.horizontalLayout_3.addWidget(self.tbrAboutProgram)
        self.twAbout.addTab(self.tabAboutProgram, "")
        self.tabAboutAuthor = QtWidgets.QWidget()
        self.tabAboutAuthor.setObjectName("tabAboutAuthor")
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout(self.tabAboutAuthor)
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.tbrAboutAuthor = QtWidgets.QTextBrowser(self.tabAboutAuthor)
        self.tbrAboutAuthor.viewport().setProperty("cursor", QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.tbrAboutAuthor.setOpenExternalLinks(True)
        self.tbrAboutAuthor.setObjectName("tbrAboutAuthor")
        self.horizontalLayout_4.addWidget(self.tbrAboutAuthor)
        self.twAbout.addTab(self.tabAboutAuthor, "")
        self.tabThanks = QtWidgets.QWidget()
        self.tabThanks.setObjectName("tabThanks")
        self.horizontalLayout_5 = QtWidgets.QHBoxLayout(self.tabThanks)
        self.horizontalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.tbrThanks = QtWidgets.QTextBrowser(self.tabThanks)
        self.tbrThanks.viewport().setProperty("cursor", QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.tbrThanks.setOpenExternalLinks(True)
        self.tbrThanks.setObjectName("tbrThanks")
        self.horizontalLayout_5.addWidget(self.tbrThanks)
        self.twAbout.addTab(self.tabThanks, "")
        self.tabLicence = QtWidgets.QWidget()
        self.tabLicence.setObjectName("tabLicence")
        self.verticalLayout_4 = QtWidgets.QVBoxLayout(self.tabLicence)
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.horizontalLayout_6 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_6.addItem(spacerItem1)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        spacerItem2 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem2)
        self.lblLicence = QtWidgets.QLabel(self.tabLicence)
        font = QtGui.QFont()
        font.setUnderline(True)
        self.lblLicence.setFont(font)
        self.lblLicence.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.lblLicence.setObjectName("lblLicence")
        self.verticalLayout.addWidget(self.lblLicence)
        self.lblLicencePic = QtWidgets.QLabel(self.tabLicence)
        self.lblLicencePic.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.lblLicencePic.setText("")
        self.lblLicencePic.setPixmap(QtGui.QPixmap(":/icons/Icons/gplv3-with-text-136x68.png"))
        self.lblLicencePic.setScaledContents(True)
        self.lblLicencePic.setObjectName("lblLicencePic")
        self.verticalLayout.addWidget(self.lblLicencePic)
        spacerItem3 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem3)
        self.horizontalLayout_6.addLayout(self.verticalLayout)
        spacerItem4 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_6.addItem(spacerItem4)
        self.verticalLayout_4.addLayout(self.horizontalLayout_6)
        self.twAbout.addTab(self.tabLicence, "")
        self.verticalLayout_3.addWidget(self.twAbout)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem5 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem5)
        self.btnClose = QtWidgets.QPushButton(dlgAbout)
        self.btnClose.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/icons/Icons/128x128/close.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.btnClose.setIcon(icon1)
        self.btnClose.setObjectName("btnClose")
        self.horizontalLayout.addWidget(self.btnClose)
        self.verticalLayout_3.addLayout(self.horizontalLayout)
        self.horizontalLayout_2.addLayout(self.verticalLayout_3)

        self.retranslateUi(dlgAbout)
        self.twAbout.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(dlgAbout)

    def retranslateUi(self, dlgAbout):
        _translate = QtCore.QCoreApplication.translate
        dlgAbout.setWindowTitle(_translate("dlgAbout", "About program"))
        self.tbrAboutProgram.setHtml(_translate("dlgAbout", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Arial\'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Check Email</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Version 1.0.0</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Lightweght program for monitoring new Emails</p></body></html>"))
        self.twAbout.setTabText(self.twAbout.indexOf(self.tabAboutProgram), _translate("dlgAbout", "About program"))
        self.tbrAboutAuthor.setHtml(_translate("dlgAbout", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Arial\'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Alexander Kostuchkov &lt;<a href=\"mailto:alkostuchkov@gmail.com\"><span style=\" text-decoration: underline; color:#0000ff;\">alkostuchkov@gmail.com</span></a>&gt;</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Donate: </p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/icons/Icons/128x128/payeer.png\" />  P1016899486</p></body></html>"))
        self.twAbout.setTabText(self.twAbout.indexOf(self.tabAboutAuthor), _translate("dlgAbout", "About author"))
        self.tbrThanks.setHtml(_translate("dlgAbout", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Arial\'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Vlad Ilushnikov &lt;<a href=\"mailto:niglad73@mail.ru\"><span style=\" text-decoration: underline; color:#0000ff;\">niglad73@mail.ru</span></a>&gt;</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.twAbout.setTabText(self.twAbout.indexOf(self.tabThanks), _translate("dlgAbout", "Thanks"))
        self.lblLicence.setText(_translate("dlgAbout", "GNU GENERAL PUBLIC LICENSE"))
        self.twAbout.setTabText(self.twAbout.indexOf(self.tabLicence), _translate("dlgAbout", "Licence"))
        self.btnClose.setText(_translate("dlgAbout", "Close"))

import resources_rc
